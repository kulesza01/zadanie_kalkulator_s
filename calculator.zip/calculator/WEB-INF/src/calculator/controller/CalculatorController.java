package calculator.controller;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.*;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import calculator.model.Currencies;


class Countries {
	static final String GREAT_BRITAIN = "GBP";
	static final String GERMANY = "EUR";
	static final String POLAND = "PLN";
}

class Country {
	static final int workingDaysNumber = 22;
	String nbpExchangeRates;
	String currencyName;
	String dailySalary;
	double tax;
	double fixedCosts;
	
	// Constructor
	public Country(String nbpExchangeRates,
			String currencyName,
			String dailySalary,
			double tax,
			double fixedCosts) {
		this.nbpExchangeRates = nbpExchangeRates;
		this.currencyName = currencyName;
		this.dailySalary = dailySalary;
		this.tax = tax;
		this.fixedCosts = fixedCosts;
	}
	
	double getExchangeRate() {
		Double exchangeRate = 1.0; // PLN
		// Get exchange rate
		if (currencyName != Countries.POLAND) {
			String currencyString = new StringBuilder().append("\"").append(currencyName).append("\"").toString();
			int indexBegin = nbpExchangeRates.lastIndexOf(currencyString);
			String valueString = nbpExchangeRates.substring(indexBegin + 12, indexBegin + 17);
			exchangeRate = Double.parseDouble(valueString);
			System.out.println(exchangeRate);
		}
		
		return exchangeRate;		
	}
	
	public String countNetSalary() {
		double exchangeRate = getExchangeRate();
		double monthlySalary = Double.parseDouble(dailySalary) * (double)workingDaysNumber * exchangeRate;
		double taxValue = monthlySalary * tax/100.0;
		String result = new DecimalFormat("#.0#").format(monthlySalary - taxValue - fixedCosts * exchangeRate);
		return result;
	}
}



@Controller
public class CalculatorController {

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Model model) {
		model.addAttribute("GBP", "0");
		model.addAttribute("EUR", "0");
		model.addAttribute("PLN", "0");

		return "start";
	}

	@RequestMapping(value = "/calc", method = RequestMethod.POST)
	public String calc(@Validated Currencies currencies, Model model) {	
		
		String errorText = null;
		String nbpExchangeRates = null;
		
		try {
			URL url = new URL("http://api.nbp.pl/api/exchangerates/tables/C");
			BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
	        
			nbpExchangeRates = in.readLine();
	        System.out.println(nbpExchangeRates);
	        in.close();
		} 
		catch (Exception e) {
			errorText = "Nie mo�na pobra� kurs�w walut.";
			System.out.println(errorText);
		}
		
		if (errorText == null)
		{
			Country greatBritain = new Country(nbpExchangeRates, // NBP exchange rates
					Countries.GREAT_BRITAIN, // country currency name
					currencies.getGBP(), // daily salary
					25.0, // tax
					600.0); //
	        System.out.println(greatBritain.countNetSalary());
			
			Country germany = new Country(nbpExchangeRates, // NBP exchange rates
					Countries.GERMANY, // country currency name
					currencies.getEUR(), // daily salary
					20.0, // tax
					800.0); //
	        System.out.println(germany.countNetSalary());
			
			Country poland = new Country(nbpExchangeRates, // NBP exchange rates
					Countries.POLAND, // country currency name
					currencies.getPLN(), // daily salary
					19.0, // tax
					1200.0); //
	        System.out.println(poland.countNetSalary());
				
	        model.addAttribute("GBP", greatBritain.countNetSalary());
	        model.addAttribute("EUR", germany.countNetSalary());
	        model.addAttribute("PLN", poland.countNetSalary());
		}
		
		return "result";
	}
}
