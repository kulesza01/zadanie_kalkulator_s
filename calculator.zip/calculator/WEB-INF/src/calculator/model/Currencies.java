package calculator.model;

public class Currencies {
	private String GBP;
	private String EUR;
	private String PLN;

	public String getGBP() {
		return GBP;
	}

	public void setGBP(String GBP) {
		this.GBP = GBP;
	}

	public String getEUR() {
		return EUR;
	}

	public void setEUR(String EUR) {
		this.EUR = EUR;
	}

	public String getPLN() {
		return PLN;
	}

	public void setPLN(String PLN) {
		this.PLN = PLN;
	}
}
